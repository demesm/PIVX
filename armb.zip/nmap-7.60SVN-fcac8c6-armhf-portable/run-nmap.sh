#!/bin/bash
NMAPDIR=nmap-data-0.7.60SVN-3708259 ./nmap $@
